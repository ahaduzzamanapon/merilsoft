 <?php
//   $to = 'shakil4014008@gmail.com';
//         $from = 'From '.$email;
//         $subject1     = 'Subject '.$subject;
//         $body = "Name: ".$name."\n Subject: ".$subject1."\n Email: ".$email."\n Message: ".$message;

//         $check = mail($to, $from, $body);
//         if($check == true){
//             echo 'Send Successfully';
//         }
//         else{
//             echo 'Not Send!';
//         }

            
  echo '<script type="text/javascript">alert("Your email sent!");</script>';
  

  
    
?>